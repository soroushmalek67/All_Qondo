<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
    	<title>Sign Up Confirmation</title>
    </head>
    <body>
        {!!$emailbody!!}
    </body>
</html>