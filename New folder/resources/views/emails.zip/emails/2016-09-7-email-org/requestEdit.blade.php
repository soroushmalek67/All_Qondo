<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
    	<title>Request Edit by Admin </title>
    </head>
    <body>
         {!!$emailbody!!}
    </body>
</html>