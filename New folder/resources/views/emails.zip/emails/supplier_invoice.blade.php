<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
    </head>
    <body>
        <div style="max-width: 800px;padding-right: 15px;padding-left: 15px;margin-right: auto;margin-left: auto;">
            <div style="margin-right: 50px;margin-left:  50px;">
                <a href="/"><img src="{{url('img/front/inner_logo.gif')}}" alt="qondo"></a>
            </div>
            
            {!!$emailbody!!}
            
            
            <div style="background: #f19432;max-height: 75px;height: 75px;">
                <a href="{{url('contact-us')}}" style="margin-right: 10px;margin-left: 150px;">  <p style="font-size: 20px;color: white;float:left;margin-left: 50px"><span style="font-weight: bold">Contact</span> us</p></a>
                <div style='margin: 20px 50px 20px 0;float:right;'>
                    <a href="http://www.firmogram.com/blog/" style="margin-right: 10px;margin-left: 150px;"><img src="{{asset('img/invoice/blog-icon.png')}}"></a>
                    <a href="https://www.facebook.com/firmogram/" style="margin-right: 10px;"><img src="{{asset('img/invoice/icon_fb.png')}}"></a>
                    <a href="https://twitter.com/firmogram" style="margin-right: 10px;"><img src="{{asset('img/invoice/icon_twitter.png')}}"></a>
                    
            </div>
        </div>
    </body>
</html>


<!--Desgin for invoice-->
<!--<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
    </head>
    <body>
        <div style="width: 54.6%;padding-right: 15px;padding-left: 15px;margin-right: auto;margin-left: auto;">
            <div style="margin-right: 50px;margin-left:  50px;">
                <a href="/"><img src="https://localhost/firmogram/devp/public/img/front/inner_logo.gif" alt="Firmogram"></a>
                <a href="/"><img src="{{url('img/front/icon_calander.png')}}" alt="Firmogram"></a>
            </div>
            <div style="margin-right: 50px;margin-left:  50px;">
                <p style="color: #555353;"></p>
                <h1 style="color: #555353;">Request Title: <span style="font-size: 22px;">@request_title</span></h1>
                <table style="border-collapse: collapse;width: 100%;text-align: center;margin-bottom: 20px;">
                    <tr>
                        <th style="color: #555353;border:1px solid;padding: 10px 0;width: 20%;">Buyer Name</th>
                        <td style="color: #555353;border:1px solid;padding: 10px 0;width: 80%;">@buyer_name</td>
                    </tr>
                    <tr>
                        <th style="color: #555353;border:1px solid;padding: 10px 0;width: 20%;">Supplier Name</th>
                        <td style="color: #555353;border:1px solid;padding: 10px 0;width: 80%;">@supplier_name</td>
                    </tr>
                    <tr>
                        <th style="color: #555353;border:1px solid;padding: 10px 0;width: 20%;">Date</th>
                        <td style="color: #555353;border:1px solid;padding: 10px 0;width: 80%;"><?php echo date('Y/m/d'); ?></td>
                    </tr>
                    <tr>
                        <th style="color: #555353;border:1px solid;padding: 10px 0;width: 20%;">Total Amount</th>
                        <td style="color: #555353;border:1px solid;padding: 10px 0;width: 80%;">@price</td>
                    </tr>
                </table>
            </div>
            <div style="background: #f19432;max-height: 75px;height: 75px;">
                <p style="font-size: 20px;color: white;width: 35%;float:left;margin-left: 50px"><span style="font-weight: bold">Contact</span> with us</p>
                <div style='width: 50%;margin: 20px 0;float:right;'>
                    <a href="www.facebook.com" style="margin-right: 10px;margin-left: 150px;"><img src="https://localhost/firmogram/devp/public/img/invoice/icon_fb.png"></a>
                    <a href="www.twitter.com" style="margin-right: 10px;"><img src="https://localhost/firmogram/devp/public/img/invoice/icon_twitter.png"></a>
                    <a href="www.google.com" style="margin-right: 10px;"><img src="https://localhost/firmogram/devp/public/img/invoice/icon_google.png"></a>
                    <a href="www.youtube.com" style="margin-right: 10px;"><img src="https://localhost/firmogram/devp/public/img/invoice/icon_youtube.png"></a>
                    <a href="www.in.com" style="margin-right: 10px;"><img src="https://localhost/firmogram/devp/public/img/invoice/icon_in.png"></a>
                </div>
            </div>
        </div>
    </body>
</html>-->

<!--PSD to HTML-->

<!--<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
    </head>
    <body>
        <div style="width: 100%;padding-right:15px;padding-left:15px;margin-right:auto;margin-left:auto;">
            <div style="margin-right: 50px;margin-left:  50px;">
                <a href="/"><img src="https://localhost/firmogram/devp/public/img/front/inner_logo.gif" alt="Firmogram"></a>
                <a href="/"><img src="{{url('img/front/icon_calander.png')}}" alt="Firmogram"></a>
            </div>
            <div>
                <img src="https://localhost/firmogram/devp/public/img/invoice/design-1.jpg" alt="Firmogram">
            </div>
            <div style="margin-right:  50px;margin-left: 50px;">
                <p style="font-size: 19px;color: #555353;">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
            </div>
            <div style="margin-right:  50px;margin-left: 50px;">
                <ul style="list-style: none;padding:0px">
                    <li style="font-size: 16px;color: #555353;margin-bottom: 3px;"><img src="https://localhost/firmogram/devp/public/img/invoice/chechbox.png" alt="checkbox"> Lorem ipsum dolor sit amet, et nihil expetenda dolor sit amet, et nihil expetenda</li>
                    <li style="font-size: 16px;color: #555353;margin-bottom: 3px;"><img src="https://localhost/firmogram/devp/public/img/invoice/chechbox.png" alt="checkbox"> Lorem ipsum dolor sit amet, et nihil expetenda dolor sit amet, et nihil expetenda</li>
                    <li style="font-size: 16px;color: #555353;margin-bottom: 3px;"><img src="https://localhost/firmogram/devp/public/img/invoice/chechbox.png" alt="checkbox"> Lorem ipsum dolor sit amet, et nihil expetenda dolor sit amet, et nihil expetenda</li>
                </ul>
                <p style="font-size: 19px;color: #555353;"></p>
            </div>
            <div style="background: #f19432;max-height: 75px;height: 75px;">
                <p style="width: 40%;margin: 20px 40px 20px 0;float:right;text-align: right;"><span style="font-weight: bold">Contact</span> with us</p>
                <div style='width: 50%;margin: 20px 0;float:right;'>
                    <a href="www.facebook.com" style="margin-right: 10px;margin-left: 150px;"><img src="https://localhost/firmogram/devp/public/img/invoice/icon_fb.png"></a>
                    <a href="www.twitter.com" style="margin-right: 10px;"><img src="https://localhost/firmogram/devp/public/img/invoice/icon_twitter.png"></a>
                    <a href="www.google.com" style="margin-right: 10px;"><img src="https://localhost/firmogram/devp/public/img/invoice/icon_google.png"></a>
                    <a href="www.youtube.com" style="margin-right: 10px;"><img src="https://localhost/firmogram/devp/public/img/invoice/icon_youtube.png"></a>
                    <a href="www.in.com" style="margin-right: 10px;"><img src="https://localhost/firmogram/devp/public/img/invoice/icon_in.png"></a>
                </div>
            </div>
        </div>
    </body>
</html>-->