        <section class="newsletterSection">
            <div class="container">
                <div class="homeSmallContiner">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="newletterCont">
                                <h2>NEED MORE INFO?</h2>
                                <p>
                                    <input id="newsletteremail" type="email" name="newletterEmail" class="input-lg" placeholder="Enter Your Email Address"/>
                                </p>
                                <p><input type="button" value="SUBSCRIBE" class="btn btnWithRightArrow" onclick="newsLetter(this)" /></p>
                                <p id="response"></p>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="newletterCont">
                                <h2>GET STARTED TODAY!</h2>
                                <p>Create competitive advantage with QONDO by procuring from quality local services!</p>
                                <p><a class="btn btnWithRightArrow" href="{{url('request-service/1')}}">REQUEST A QUOTE</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>