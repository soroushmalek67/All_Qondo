        <!--[if lte IE 9]>
        <script type="text/javascript">window.location.href = "{{url('outdated_browser')}}"</script>
        <![endif]-->