<style type="text/css">
/***********************Outdated Browser Error Start***************************/
#warning{
    background-color: #fff;
    border-bottom: 4px solid #000066;
    height: 135px;
    padding: 4px;
    position: fixed;
    top: 0;
    width: 100%;
    left: 0;
    bottom: 0;
    right: 0;
    z-index: 2147483647;
    height: 100vh;
}
#warning .red{
    color: red;
    font-size: 21px;
}
</style>


        <div id="warning" style="display: block !important;">
        <h4 class="red">‘WARNING: Your Current Browser Is Outdated!’, Please upgrade your Internet Explorer browser to a newer version.</h4>
        <p>As an alternative, you can use either of the options below to browse the site:</p>
        <p>Please upgrade to <a href='http://getfirefox.com'>FireFox</a>, <a href='https://www.google.com/chrome/browser/desktop/'>Chrome</a> or <a href='http://www.microsoft.com/windows/downloads/ie/getitnow.mspx'>Internet Explorer 10 or 11</a>. Thank You!</p>
        </div>