        <footer>
            <div class="container">
                <div class="row footerSections">
                    <div class="">
                        <h5>QUICK LINKS</h5>
                        <ul>
                            <li><a class="linkToHowItWorks" href="{{url('how-it-works')}}">How it works</a></li>
                            <li><a href="{{url('auth/login')}}">Sign In</a></li>
                            <li><a href="{{ url('categories') }}">Categories</a></li>
                            <li><a href="{{url('auth/register')}}">Register as a Contractor</a></li>
                            <li><a href="{{url('suppliers-list')}}">Pro Directory</a></li>
                            <!--<li><a href="http://support.firmogram.ca/" target="_blank">Support</a></li>-->
                            <!--<li><a href="{{url('')}}/blog/" target="_blank">Blog</a></li>-->
                            <!--<li><a href="{{url('about/')}}">About</a></li>-->
                            <li><a href="{{url('faq/')}}">FAQ</a></li>
                        </ul>
                    </div>
                    <div class="">
                        <!--<div class="hidden-lg hidden-md hidden-sm">-->
                        <div class="">
                            <h5>FOLLOW US</h5>
                            <p class="socialLinksCont">
<!--                                <a href="https://www.linkedin.com/company/firmogram-ecosystem-visualization?report%2Esuccess=MlmG7g_fqFRfD4iVhHgr0FomJDOL3vciIT4v8pi3EYkZnZLjFuJfr4acCeXZnFnMvaat" target="_blank">
                                    <img src="{{ asset('img/front/icon_linkedin.png') }}" alt="Linkedin" width="22" height="22"/></a>-->
                                <a href="https://www.facebook.com/qondo/" target="_blank">
                                    <img src="{{ asset('img/front/icon_fb.gif') }}" alt="Facebook" width="12" height="20"/></a>
                                <a href="https://twitter.com/qondopro" target="_blank">
                                    <img src="{{ asset('img/front/icon_tw.gif') }}" alt="Twitter" width="26" height="21"/></a>
<!--                                <a href="https://plus.google.com/u/0/104925233774964257643/posts" target="_blank">
                                    <img src="{{ asset('img/front/icon_google_plus.png') }}" alt="Google Plus" width="25" height="24"/></a>
                                <a href="javascript:;">
                                    <img src="{{ asset('img/front/icon_instagram.png') }}" alt="Instagram" width="25" height="25"/></a>
                                <a href="https://www.youtube.com/watch?v=Dn36nSiPAw8" target="_blank">
                                    <img src="{{ asset('img/front/icon_yt.gif') }}" alt="Instagram" width="25" height="24"/></a>
                                <a href="https://www.pinterest.com/firmogram/" target="_blank">
                                    <img src="{{ asset('img/front/icon_pinterest.png') }}" alt="Pinterest" width="25" height="24"/></a>-->
                            </p><br/>
                        </div>
                        <p>A Proud Member of:</p>
                        <p><img src="{{asset('img/front/company_logos/cci_logo.png')}}" alt="" width="200"/></p>
                    </div>
                    <div class="">
                        <h5>CONTACT INFORMATION</h5>
                        <p>P.O. Box 45021, Vancouver BC,<br/>Canada V6S 2M8</p>
                        <p><img src="{{ asset('img/front/icon_phone.gif') }}" alt=""/> TEL +1 855 782 6882</p>
<!--                        <p><img src="{{ asset('img/front/icon_print.gif') }}" alt=""/> FAX +1 604 568 8891</p>-->
                    </div>
                    <div class="text-center">
                        <img src="{{ asset('img/front/Firmogram_r10_c8.png') }}" alt="Qondo"/><br/>
                        <div class="footer-logo-text-sec">
                            <p class="footer-logo-text">MEETING THE NEEDS OF STRATA PROPERTY MANAGERS.<br/>
                                Connecting condo residents and strata managers to a vetted network of contractors and trades
                            </p>
                        </div>
<!--                        <a href="#" onclick="window.open('https://www.sitelock.com/verify.php?site=firmogram.com','SiteLock','width=600,height=600,left=160,top=170');" >
                            <img alt="SiteLock" title="SiteLock" src="//shield.sitelock.com/shield/firmogram.com"/>
                        </a>-->
                    </div>
                </div>
				<div class="row services-divi">
                     <div class="" >
<!--                        <h5>Services</h5>-->
                     <?php   $services = getServices();
					 //echo "<pre>";
					 //print_r($services);
					 //echo "</pre>";
					 
                     ?>
                        <ul>
                          <li class="services-divi-li" style="display:inline-block;padding-left: 10px;">

                     <?php foreach($services as $service){ ?>
                      <!--<a href="{{url('request-service/'.$service->slug)}}">-->   
                     
                      <a href="{{url('request-service/'.$service->slug)}}" style="font-size:15px;">
                          <?php echo $service->name; ?>
                      </a> |                            
					 <?php } ?>
                            
                          </li>
                      </ul>
                    </div>
                    
                </div>
                <div class="row">
                    <div class="col-md-12 copyrightTextCont">
                        <p>Copyright <?php echo date('Y'); ?> Qondo. All Rights Reserved.
                            <a href="{{url('privacy-policy')}}">Privacy Policy</a> .
                            <a href="{{url('contact-us')}}">Contact Us</a> . 
                            <a href="{{url('terms')}}">Terms of Use</a>
                        </p>
                    </div>
                </div>
            </div>
        </footer>
<!--        <div class="hidden-xs side_follow_bar">
            <ul>
                <li>
                    <a class="an-linkedin" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=https://www.firmogram.com&title=Firmogram" target="_blank">
                        <img src="{{ asset('img/front/ic_linkedin.png') }}" alt="Linkedin" width="22" height="22"/>
                    </a>
                </li>
                <li>
                    <a class="an-facebook" href="http://www.facebook.com/sharer.php?u=https://www.qondo.ca/" target="_blank">
                        <img src="{{ asset('img/front/ic_facebook.png') }}" alt="Linkedin" width="22" height="22"/>
                    </a>
                </li>
                <li>
                    <a class="an-twitter" href="https://twitter.com/share?url=https://www.qondo.ca/" target="_blank">
                        <img src="{{ asset('img/front/ic_twitter.png') }}" alt="Linkedin" width="22" height="22"/>
                    </a>
                </li>
                <li>
                    <a class="an-gplus" href="https://plus.google.com/share?url=https://www.firmogram.com" target="_blank">
                        <img src="{{ asset('img/front/ic_googleplus.png') }}" alt="Linkedin" width="22" height="22"/>
                    </a>
                </li>
                <li>
                    <a class="an-youtube" href="https://www.youtube.com/watch?v=Dn36nSiPAw8" target="_blank">
                        <img src="{{ asset('img/front/ic-youtube.png') }}" alt="Linkedin" width="22" height="22"/>
                    </a>
                </li>
                <li>
                    <a class="an-pin" href="https://pinterest.com/pin/create/button/?url=https%3A//www.firmogram.com" target="_blank">
                        <img src="{{ asset('img/front/ic_pinterest.png') }}" alt="Linkedin" width="22" height="22"/>
                    </a>
                </li>
            </ul>
        </div>-->


        <div class="modal ajaxLoadingPopup" id="loading-indicator" style="display:none; text-align:center">
            <img src="{{ asset('img/ajax-loader.gif') }}" alt="Loading..." width="60" height="60" />
                <!--<p>Please wait while we load .........</p><br /><br />-->

        </div>
        @include('partials.scripts')