<!DOCTYPE html>
<html>

@include('admin.partials.htmlheader')

@yield('content')

</html>