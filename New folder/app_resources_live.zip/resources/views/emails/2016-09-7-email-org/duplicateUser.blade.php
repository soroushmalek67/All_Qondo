<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
    	<title> Add Duplicate Company </title>
    </head>
     {!!$emailbody!!}
</html>