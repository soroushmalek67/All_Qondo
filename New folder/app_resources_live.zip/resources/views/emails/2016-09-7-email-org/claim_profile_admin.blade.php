@extends('templates.email_template')
    @section('title','Claim Profile Request')
    @stop
    @section('content')
        
        {!!$emailbody!!}
    
    @stop
